IMDM Prefab Kit placeholder package.
